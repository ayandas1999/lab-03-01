#!/bin/bash
chown -R webapp:webapp /var/www/html/
chmod -R 755 /var/www/html/
